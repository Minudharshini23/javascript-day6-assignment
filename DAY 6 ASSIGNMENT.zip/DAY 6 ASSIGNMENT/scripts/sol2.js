let input=prompt("enter the number:");
let end=prompt("enter the range:");
for(let i=1;i<=end;i++)
{
document.write(input,"x",i,"=",(input*i),"<br \>");
document.body.style.backgroundColor="yellow";
}